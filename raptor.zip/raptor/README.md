# Oauth2 and OIDC client

This service is an Otp identity that verify login and register with send code to email or mobile number

## Installation

```bash
RUN go mod download
```

## RUN
Run in localhost
```bash
 go run main.go --config ./config_sample.json serve generate-key
```
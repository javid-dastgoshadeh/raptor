package main

import (
	"raptor/cmd"
)

func main() {
	cmd.Execute()
}

package models

import "crypto/rsa"

var PrivateKey *rsa.PrivateKey
var RefreshTokenPrivateKey *rsa.PrivateKey
var RefreshTokenPublicKey *rsa.PublicKey

package models

//
//import "golang.org/x/net/http2"
//
//type CustomErrGeneral struct {
//	Status http2.ErrCode
//	Code   int32
//	Msg    string
//}
//
//func (err *CustomErrGeneral) Error() string {
//	return err.Msg
//}
//
//type CustomErrChangeIdentifier struct {
//	Status http2.ErrCode
//	Code   int32
//	Msg    string
//}
//
//func (err *CustomErrChangeIdentifier) Error() string {
//	return err.Msg
//}
//
//type CustomErrVerificationFormat struct {
//	Status http2.ErrCode
//	Code   int32
//	Msg    string
//}
//type CustomErrTraitsFormat struct {
//	Status http2.ErrCode
//	Code   int32
//	Msg    string
//}
//type CustomErrGenerationAccessToken struct {
//	Status http2.ErrCode
//	Code   int32
//	Msg    string
//}
//type CustomErrExpireOtpCodeTime struct {
//	Status http2.ErrCode
//	Code   int32
//	Msg    string
//}
//type CustomErrConnectToGraphql struct {
//	Status http2.ErrCode
//	Code   int32
//	Msg    string
//}
//type CustomErrCreateKratosLoginFlow struct {
//	Status http2.ErrCode
//	Code   int32
//	Msg    string
//}
//
//type CustomErrProviderConnection struct {
//	Status http2.ErrCode
//	Code   int32
//	Msg    string
//}
//
//type CustomErrProviderToken struct {
//	Status http2.ErrCode
//	Code   int32
//	Msg    string
//}
//
//type CustomErrOtpCodeNotMatched struct {
//	Status http2.ErrCode
//	Code   int32
//	Msg    string
//}
//
//type CustomErrExpireCodeTime struct {
//	Status http2.ErrCode
//	Code   int32
//	Msg    string
//}
//
//type CustomErrInvalidToken struct {
//	Status http2.ErrCode
//	Code   int32
//	Msg    string
//}
//
//type CustomErrKavenegarApi struct {
//	Status http2.ErrCode
//	Code   int32
//	Msg    string
//}
//
//type CustomErrKavenegarHttp struct {
//	Status http2.ErrCode
//	Code   int32
//	Msg    string
//}
//
//type CustomErrInternalServer struct {
//	Status http2.ErrCode
//	Code   int32
//	Msg    string
//}
//
//type CustomErrSubmitLoginFlow struct {
//	Status http2.ErrCode
//	Code   int32
//	Msg    string
//}
//
//type CustomErrIdentityFormat struct {
//	Status http2.ErrCode
//	Code   int32
//	Msg    string
//}
//
//type CustomErrCreatingRegisterFlow struct {
//	Status http2.ErrCode
//	Code   int32
//	Msg    string
//}
//type CustomErrHttpRequest struct {
//	Status http2.ErrCode
//	Code   int32
//	Msg    string
//}
//type CustomErrUnauthorized struct {
//	Status http2.ErrCode
//	Code   int32
//	Msg    string
//}
//type CustomErrAuthorizedFormat struct {
//	Status http2.ErrCode
//	Code   int32
//	Msg    string
//}
//type CustomErrEmptyJwtToken struct {
//	Status http2.ErrCode
//	Code   int32
//	Msg    string
//}
//type CustomErrJwtToken struct {
//	Status http2.ErrCode
//	Code   int32
//	Msg    string
//}

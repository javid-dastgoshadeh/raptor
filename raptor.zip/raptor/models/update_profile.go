package models

type UpdateRequest struct {
	Traits *Traits `json:"traits"`
}

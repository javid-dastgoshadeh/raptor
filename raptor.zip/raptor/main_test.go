package main

import "testing"

func TestNothing(t *testing.T) {
	// t.Errorf("Error occurred")
}
